import React from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import About from "./components/Login";
import Home from "./components/Home";
//import Home from "./components/Home";
//import Topics from "./components/Topics";

const App = () => {
  return(
    <Router>
      <div>
        <ul>
          <li>
            <Link to="/components/Login">Login</Link>
          </li>
          <li>
            <Link to="/components/Home">Home</Link>
          </li>
        </ul>


      <Switch>
        <Route exact path='/components/Login'>
          <About />
        </Route>
        <Route path="/components/Home">
          <Home />
          </Route>
      </Switch>
      </div>
    </Router>
  )
}
export default App;
