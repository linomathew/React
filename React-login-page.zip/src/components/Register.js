import React from 'react';
import './Register.css';

const Register = () => (
  <div>
    <h2 id='loginStyle'>Welcome to sign up page</h2>
  </div>
);

export default Register;
